<?php

require_once "../entities/vehiculo.php";

class Colectivo extends Vehiculo {}
?>