    <?php
    require_once "../entities/vehiculo.php";

    class Auto_clasico extends Vehiculo {}
    ?>